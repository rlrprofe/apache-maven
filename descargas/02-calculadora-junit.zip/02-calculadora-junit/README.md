# 02 · Calculadora con JUnit 5

**Finalidad didáctica:** comprender `src/test/java`, la dependencia `scope=test`, las aserciones y los informes Surefire.

## Ejecución
`mvn clean test` y `mvn test -Dtest=CalculadoraTest`.

## Práctica guiada
1. Ejecuta las pruebas y observa el resultado.
2. Cambia temporalmente `assertEquals(7, ...)` por `assertEquals(8, ...)`.
3. Repite `mvn test` y revisa `target/surefire-reports`.
4. Restaura la prueba y ejecuta `mvn clean verify`.

## Preguntas
¿Por qué JUnit no se incluye como dependencia de ejecución? ¿Qué aporta probar la excepción de división por cero?
