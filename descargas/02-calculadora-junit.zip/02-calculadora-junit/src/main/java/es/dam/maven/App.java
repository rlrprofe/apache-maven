package es.dam.maven;
/** Ejemplo de aplicación que utiliza el servicio Calculadora. */
public final class App {
    private App() { }
    /** @param args argumentos no utilizados */
    public static void main(String[] args) {
        Calculadora c = new Calculadora();
        System.out.println("3 + 4 = " + c.sumar(3, 4));
    }
}
