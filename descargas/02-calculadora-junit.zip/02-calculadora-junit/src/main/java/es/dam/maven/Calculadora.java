package es.dam.maven;
/** Servicio aritmético utilizado para aprender pruebas unitarias. */
public class Calculadora {
    /** Suma dos enteros. @param a primer sumando @param b segundo sumando @return suma */
    public int sumar(int a, int b) { return a + b; }
    /** Divide dos números; rechaza divisor cero.
     * @param a dividendo @param b divisor @return cociente
     * @throws IllegalArgumentException si b es cero
     */
    public double dividir(double a, double b) {
        if (b == 0) throw new IllegalArgumentException("El divisor no puede ser cero");
        return a / b;
    }
}
