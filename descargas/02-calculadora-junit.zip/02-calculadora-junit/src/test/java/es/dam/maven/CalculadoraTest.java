package es.dam.maven;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
/** Pruebas unitarias para comprobar resultados y errores esperados. */
class CalculadoraTest {
    @Test void sumarDosPositivos() {
        assertEquals(7, new Calculadora().sumar(3, 4));
    }
    @Test void sumarNegativos() {
        assertEquals(-5, new Calculadora().sumar(-2, -3));
    }
    @Test void dividir() {
        assertEquals(2.5, new Calculadora().dividir(5, 2));
    }
    @Test void dividirPorCero() {
        assertThrows(IllegalArgumentException.class, () -> new Calculadora().dividir(5, 0));
    }
}
