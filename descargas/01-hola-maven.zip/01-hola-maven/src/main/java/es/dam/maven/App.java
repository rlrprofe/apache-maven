package es.dam.maven;
/**
 * Punto de entrada de la primera aplicación Maven.
 * Permite comprobar que el proyecto se compila y ejecuta correctamente.
 */
public final class App {
    private App() { }
    /** Inicia el programa. @param args argumentos de consola (no utilizados) */
    public static void main(String[] args) {
        // Cambia este mensaje y repite la compilación.
        System.out.println("Hola, Maven. Proyecto compilado con Java 21.");
    }
}
