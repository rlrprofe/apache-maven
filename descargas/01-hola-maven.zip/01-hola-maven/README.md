# 01 · Hola Maven

**Finalidad didáctica:** reconocer el POM, compilar, localizar `target/`, ejecutar una clase principal y generar un JAR ejecutable sin dependencias externas.

## Requisitos
Java 21 y Maven 3.9+.

## Pasos
1. Abrir la carpeta que contiene `pom.xml`.
2. `mvn clean package`.
3. `mvn exec:java`.
4. `java -jar target/hola-maven-1.0-SNAPSHOT.jar`.
5. Cambiar el mensaje de `App.java` y repetir.

## Comprobación
Debe mostrarse `Hola, Maven. Proyecto compilado con Java 21.`

## Preguntas
¿Qué se crea en `target/classes`? ¿Por qué el JAR se llama `hola-maven-1.0-SNAPSHOT.jar`? ¿Qué plugin configura `Main-Class`?
