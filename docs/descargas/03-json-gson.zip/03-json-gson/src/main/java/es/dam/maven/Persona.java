package es.dam.maven;
/** Modelo de una persona que será serializada a JSON. */
public class Persona {
    private String nombre;
    private int edad;
    /** Constructor sin argumentos para herramientas de serialización. */
    public Persona() { }
    /** @param nombre nombre de la persona @param edad edad en años */
    public Persona(String nombre, int edad) { this.nombre = nombre; this.edad = edad; }
    /** @return nombre */
    public String getNombre() { return nombre; }
    /** @param nombre nuevo nombre */
    public void setNombre(String nombre) { this.nombre = nombre; }
    /** @return edad */
    public int getEdad() { return edad; }
    /** @param edad nueva edad */
    public void setEdad(int edad) { this.edad = edad; }
    @Override public String toString() { return nombre + " (" + edad + ")"; }
}
