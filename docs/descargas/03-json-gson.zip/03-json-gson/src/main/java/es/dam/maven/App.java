package es.dam.maven;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
/** Demuestra el uso de una dependencia externa y su empaquetado. */
public final class App {
    private App() { }
    /** @param args argumentos no utilizados */
    public static void main(String[] args) {
        // Gson no forma parte del JDK: Maven resuelve esta biblioteca.
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        Persona persona = new Persona("Ana", 21);
        String json = gson.toJson(persona);
        System.out.println(json);
        // Se vuelve a crear el objeto para ilustrar la deserialización.
        Persona recuperada = gson.fromJson(json, Persona.class);
        System.out.println("Recuperada: " + recuperada);
    }
}
