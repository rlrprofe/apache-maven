# 03 · JSON con Gson

**Finalidad didáctica:** añadir una dependencia externa, observar su descarga, inspeccionar el árbol y construir un JAR con dependencias.

## Ejecución
1. `mvn dependency:tree`.
2. `mvn exec:java`.
3. `mvn clean package`.
4. `java -jar target/json-gson-1.0-SNAPSHOT.jar`.

El plugin Shade incorpora Gson al JAR resultante para facilitar su ejecución.

## Actividades
Modifica nombre y edad; añade un atributo al modelo; inspecciona el JSON y explica qué diferencia hay entre serialización y deserialización.
